package com.example.myapplication;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    Button dateBtn, bookBtn;
    ToggleButton toggle;

    String selectedZone = "";
    String selectedDate = "";

    boolean confirmSelection = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        dateBtn = findViewById(R.id.dateBtn);
        bookBtn = findViewById(R.id.bookBtn);
        toggle = findViewById(R.id.toggle);

        // 🔥 Spinner Data
        String[] zones = {"Select", "North", "South", "East", "West"};

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, zones);
        spinner.setAdapter(adapter);

        // 🔥 Spinner Selection with AlertDialog
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                if(pos == 0) return;

                String zone = zones[pos];

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirm Selection")
                        .setMessage("Select " + zone + " zone?")
                        .setPositiveButton("Yes", (d, w) -> {
                            selectedZone = zone;
                            confirmSelection = true;
                        })
                        .setNegativeButton("No", (d, w) -> {
                            spinner.setSelection(0);
                            selectedZone = "";
                            confirmSelection = false;
                        })
                        .show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // 🔥 Date Picker with restriction
        dateBtn.setOnClickListener(v -> {

            Calendar cal = Calendar.getInstance();

            DatePickerDialog dp = new DatePickerDialog(this,
                    (view, y, m, d) -> {
                        selectedDate = d + "/" + (m+1) + "/" + y;
                    },
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH));

            // 🔥 MIN = tomorrow
            Calendar min = Calendar.getInstance();
            min.add(Calendar.DAY_OF_MONTH, 1);

            // 🔥 MAX = next 20 days
            Calendar max = Calendar.getInstance();
            max.add(Calendar.DAY_OF_MONTH, 20);

            dp.getDatePicker().setMinDate(min.getTimeInMillis());
            dp.getDatePicker().setMaxDate(max.getTimeInMillis());

            dp.show();
        });

        // 🔥 BOOK BUTTON
        bookBtn.setOnClickListener(v -> {

            if(!toggle.isChecked()){
                Toast.makeText(this, "Still selecting!", Toast.LENGTH_SHORT).show();
                return;
            }

            if(selectedZone.isEmpty() || selectedDate.isEmpty()){
                Toast.makeText(this, "Complete all selections", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent i = new Intent(MainActivity.this, ResultActivity.class);
            i.putExtra("zone", selectedZone);
            i.putExtra("date", selectedDate);

            startActivity(i);
        });
    }
}
