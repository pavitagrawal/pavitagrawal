package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    TextView text;
    Button back;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_result);

        text = findViewById(R.id.resultText);
        back = findViewById(R.id.backBtn);

        String zone = getIntent().getStringExtra("zone");
        String date = getIntent().getStringExtra("date");

        // 🔥 Static Data
        int people = 0;

        if (zone != null) {
            switch (zone) {
                case "North":
                    people = 100;
                    break;
                case "South":
                    people = 80;
                    break;
                case "East":
                    people = 60;
                    break;
                case "West":
                    people = 120;
                    break;
            }
        }

        text.setText("Zone: " + zone +
                "\nDate: " + date +
                "\nPeople deployed: " + people);

        back.setOnClickListener(v -> finish());
    }
}
