package com.example.myapplication;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    TextView text;
    Button dateBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        text = findViewById(R.id.resultText);
        dateBtn = findViewById(R.id.dateBtn);

        String courses = getIntent().getStringExtra("courses");
        String gender = getIntent().getStringExtra("gender");
        String stay = getIntent().getStringExtra("stay");

        String result = String.format(Locale.getDefault(), "Courses: %s\nGender: %s\nStay: %s",
                courses, gender, stay);
        text.setText(result);

        dateBtn.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();

            DatePickerDialog dp = new DatePickerDialog(this,
                    (view, y, m, d) -> {
                        String dateStr = String.format(Locale.getDefault(), "\nDate: %d/%d/%d", d, m + 1, y);
                        text.append(dateStr);
                    },
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH));

            // Allow only from 2 days after today
            Calendar minDate = Calendar.getInstance();
            minDate.add(Calendar.DAY_OF_MONTH, 2);

            dp.getDatePicker().setMinDate(minDate.getTimeInMillis());
            dp.show();
        });
    }
}
