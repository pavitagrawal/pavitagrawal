package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ToggleButton toggle;
    CheckBox cra, oe, lab, mess;
    RadioGroup group;
    Button ok, clear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggle = findViewById(R.id.toggle);
        cra = findViewById(R.id.cra);
        oe = findViewById(R.id.oe);
        lab = findViewById(R.id.lab);
        mess = findViewById(R.id.mess);
        group = findViewById(R.id.radioGroup);

        ok = findViewById(R.id.okBtn);
        clear = findViewById(R.id.clearBtn);

        // 🔥 RULE 1: ON CAMPUS → MESS AUTO SELECT
        toggle.setOnCheckedChangeListener((btn, isChecked) -> {

            if(isChecked){ // ON CAMPUS
                mess.setChecked(true);
                mess.setEnabled(false); // cannot uncheck
            } else {
                mess.setEnabled(true);
                mess.setChecked(false);
            }
        });

        // 🔥 RULE 2: CRA & OE cannot be selected together
        cra.setOnCheckedChangeListener((b, isChecked) -> {
            if(isChecked) oe.setChecked(false);
        });

        oe.setOnCheckedChangeListener((b, isChecked) -> {
            if(isChecked) cra.setChecked(false);
        });

        // OK BUTTON
        ok.setOnClickListener(v -> {

            String courses = "";

            if(cra.isChecked()) courses += "CRA ";
            if(oe.isChecked()) courses += "OE ";
            if(lab.isChecked()) courses += "LAB ";
            if(mess.isChecked()) courses += "MESS ";

            int id = group.getCheckedRadioButtonId();
            RadioButton rb = findViewById(id);
            String gender = (rb != null) ? rb.getText().toString() : "Not Selected";

            String stay = toggle.isChecked() ? "ON CAMPUS" : "OFF CAMPUS";

            Intent i = new Intent(MainActivity.this, MainActivity2.class);
            i.putExtra("courses", courses);
            i.putExtra("gender", gender);
            i.putExtra("stay", stay);

            startActivity(i);
        });

        // CLEAR BUTTON
        clear.setOnClickListener(v -> {
            cra.setChecked(false);
            oe.setChecked(false);
            lab.setChecked(false);
            mess.setChecked(false);
            mess.setEnabled(true);
            group.clearCheck();
            toggle.setChecked(false);
        });
    }

}
